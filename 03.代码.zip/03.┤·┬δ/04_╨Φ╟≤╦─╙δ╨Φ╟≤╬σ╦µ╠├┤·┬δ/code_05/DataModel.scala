/*
 * Copyright (c) 2017. Atguigu Inc. All Rights Reserved.
 * Date: 10/28/17 9:52 AM.
 * Author: wuyufei.
 */

case class PageSplitConvertRate(taskid: String, convertRate: String)