/*
 * Copyright (c) 2018. Atguigu Inc. All Rights Reserved.
 */

package com.atguigu.page

case class PageSplitConvertRate(taskid: String, convertRate: String)